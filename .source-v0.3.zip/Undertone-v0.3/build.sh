#!/bin/bash
# Builds Undertone.app, installs it to /Applications (or ~/Applications) and launches it.
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "swiftc가 없어. 먼저 터미널에서: xcode-select --install"
  exit 1
fi

APP="build/Undertone.app"
rm -rf build
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

echo "▶ 빌드 중…"
swiftc -O -swift-version 5 \
  -target "$(uname -m)-apple-macos14.0" \
  -framework AppKit -framework SwiftUI -framework ScreenCaptureKit \
  -framework CoreMedia -framework ServiceManagement -framework SceneKit \
  Sources/*.swift \
  -o "$APP/Contents/MacOS/Undertone"

cp Info.plist "$APP/Contents/Info.plist"
codesign --force --sign - "$APP" >/dev/null

DEST="/Applications"
[ -w "$DEST" ] || { DEST="$HOME/Applications"; mkdir -p "$DEST"; }

pkill -x Undertone 2>/dev/null || true
sleep 0.5
rm -rf "$DEST/Undertone.app"
cp -R "$APP" "$DEST/"

echo "✓ 설치 완료: $DEST/Undertone.app"
open "$DEST/Undertone.app"
