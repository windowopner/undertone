import SwiftUI
import SceneKit

/// SwiftUI wrapper around a SceneKit view that renders the 3D bar field.
struct BarsView: NSViewRepresentable {
    let audio: AudioReactor
    @ObservedObject var settings: Settings
    let visible: Bool

    func makeCoordinator() -> BarField { BarField(audio: audio, settings: settings) }

    func makeNSView(context: Context) -> SCNView {
        let v = SCNView(frame: .zero, options: nil)
        v.scene = context.coordinator.scene
        v.pointOfView = context.coordinator.cameraNode
        v.backgroundColor = .black
        v.antialiasingMode = .multisampling4X
        v.allowsCameraControl = false
        v.rendersContinuously = true
        v.preferredFramesPerSecond = 60
        v.delegate = context.coordinator
        v.isPlaying = true
        return v
    }

    func updateNSView(_ v: SCNView, context: Context) {
        v.preferredFramesPerSecond = visible ? 60 : 1
    }
}

/// A dense herringbone field of rectangular bars that rise with the music.
///  - bass swell ("둥~~"): the whole field lifts and slowly settles
///  - beats: a ripple spreads out from the centre
///  - highs: random bars spark upward
final class BarField: NSObject, SCNSceneRendererDelegate {
    let scene = SCNScene()
    let cameraNode = SCNNode()

    private let audio: AudioReactor
    private let settings: Settings

    private struct Bar {
        let node: SCNNode
        let x: Float, z: Float, dist: Float, seed: Float
        let orient: Int
        var h: Float
        var level: Int
    }

    private var bars: [Bar] = []
    private var geoms: [[SCNGeometry]] = [[], []]
    private var mats: [SCNMaterial] = []
    private var ripples: [(t0: Float, amp: Float)] = []
    private var prevBeat: Float = 0
    private var swell: Float = 0
    private var start: TimeInterval?
    private var maxDist: Float = 1

    private let K = 14          // brightness levels
    private let u: Float = 0.5  // world size of one pattern cell

    init(audio: AudioReactor, settings: Settings) {
        self.audio = audio
        self.settings = settings
        super.init()
        build()
    }

    // MARK: - Scene setup

    private func build() {
        scene.background.contents = NSColor.black
        scene.fogColor = NSColor.black
        scene.fogStartDistance = 12
        scene.fogEndDistance = 34
        scene.fogDensityExponent = 1.5

        // Shared materials, one per brightness level; emission is recoloured every frame.
        for _ in 0..<K {
            let m = SCNMaterial()
            m.lightingModel = .blinn
            m.diffuse.contents = NSColor(white: 0.10, alpha: 1)
            m.specular.contents = NSColor(white: 0.55, alpha: 1)
            m.emission.contents = NSColor.black
            mats.append(m)
        }

        // Bricks are 2 × 1 cells with a thin gap.
        let gap: CGFloat = 0.07
        let L = CGFloat(2 * u) - gap
        let W = CGFloat(u) - gap
        let shapes = [SCNBox(width: L, height: 1, length: W, chamferRadius: 0.02),
                      SCNBox(width: W, height: 1, length: L, chamferRadius: 0.02)]
        for (o, shape) in shapes.enumerated() {
            for i in 0..<K {
                let g = shape.copy() as! SCNGeometry
                g.materials = [mats[i]]
                geoms[o].append(g)
            }
        }

        // Herringbone tiling: diagonal staircases of (horizontal, vertical) bricks,
        // repeated every 4 cells along x.
        let xr: Float = 34, yr: Float = 26
        func add(_ cx: Float, _ cy: Float, _ o: Int) {
            guard abs(cx) <= xr, abs(cy) <= yr else { return }
            let n = SCNNode(geometry: geoms[o][0])
            n.pivot = SCNMatrix4MakeTranslation(0, -0.5, 0)   // grow from the floor up
            n.simdPosition = SIMD3<Float>(cx * u, 0, cy * u)
            n.simdScale = SIMD3<Float>(1, 0.3, 1)
            scene.rootNode.addChildNode(n)
            let wx = cx * u, wz = cy * u
            let d = (wx * wx + wz * wz).squareRoot()
            maxDist = max(maxDist, d)
            bars.append(Bar(node: n, x: wx, z: wz, dist: d,
                            seed: Float.random(in: 0...1000), orient: o, h: 0.3, level: 0))
        }
        for s in -18...18 {
            for k in -30...30 {
                add(Float(k + 1 + 4 * s), Float(k) + 0.5, 0)   // horizontal brick
                add(Float(k) + 0.5 + Float(4 * s), Float(k + 2), 1) // vertical brick
            }
        }

        // Lights
        let key = SCNNode()
        key.light = SCNLight()
        key.light!.type = .directional
        key.light!.intensity = 850
        key.light!.color = NSColor(calibratedRed: 0.82, green: 0.86, blue: 1.0, alpha: 1)
        key.simdEulerAngles = SIMD3<Float>(-1.05, 0.55, 0)
        scene.rootNode.addChildNode(key)

        let amb = SCNNode()
        amb.light = SCNLight()
        amb.light!.type = .ambient
        amb.light!.intensity = 140
        amb.light!.color = NSColor(calibratedRed: 0.35, green: 0.38, blue: 0.55, alpha: 1)
        scene.rootNode.addChildNode(amb)

        // Camera with HDR bloom so tall bars glow.
        let cam = SCNCamera()
        cam.fieldOfView = 42
        cam.zNear = 0.1
        cam.zFar = 100
        cam.wantsHDR = true
        cam.bloomThreshold = 0.55
        cam.bloomIntensity = 1.3
        cam.bloomBlurRadius = 14
        cam.vignettingIntensity = 0.6
        cam.vignettingPower = 1.2
        cameraNode.camera = cam
        cameraNode.simdPosition = SIMD3<Float>(0, 12, 14)
        cameraNode.simdLook(at: SIMD3<Float>(0, 0, -1))
        scene.rootNode.addChildNode(cameraNode)
    }

    // MARK: - Per-frame update (render thread)

    private func noise(_ s: Float, _ k: Int) -> Float {
        let v = sin(s * 12.9898 + Float(k % 100_000) * 78.233) * 43758.5453
        return v - v.rounded(.down)
    }

    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if start == nil { start = time }
        let t = Float(time - (start ?? time))
        let lv = audio.snapshot().scaled(settings.sensitivity)

        // New ripple on each beat's rising edge.
        if lv.beat > 0.9 && prevBeat < 0.6 {
            ripples.append((t0: t, amp: 0.6 + 0.9 * lv.bass))
        }
        prevBeat = lv.beat
        ripples.removeAll { t - $0.t0 > 3.5 }

        // "둥~~": rise quickly, settle slowly.
        swell += (lv.bass - swell) * (lv.bass > swell ? 0.25 : 0.035)

        let hiBucket = Int(t * 10)
        let sparkle = lv.high > 0.55

        for i in bars.indices {
            var b = bars[i]

            // Idle breathing so the field is never dead.
            var target: Float = 0.2 + 0.1 * (sin(b.x * 0.35 + t * 0.7) + sin(b.z * 0.42 - t * 0.5))
            // Bass swell, strongest in the middle.
            target += 1.9 * swell * (1 - 0.55 * b.dist / maxDist)
            // Beat ripples travelling outward.
            for r in ripples {
                let age = t - r.t0
                let d = b.dist - age * 8
                target += r.amp * 2.2 * exp(-d * d / 1.8) * exp(-age * 0.9)
            }
            // High-frequency sparks.
            if sparkle && noise(b.seed, hiBucket) > 0.985 {
                target += 0.9 * lv.high
            }
            target = max(0.05, target)

            b.h += (target - b.h) * (target > b.h ? 0.45 : 0.1)
            b.node.simdScale = SIMD3<Float>(1, 0.15 + b.h * 1.6, 1)

            let lvl = min(K - 1, max(0, Int(b.h / 2.6 * Float(K))))
            if lvl != b.level {
                b.node.geometry = geoms[b.orient][lvl]
                b.level = lvl
            }
            bars[i] = b
        }

        // Recolour the brightness levels; mids push the hue around.
        var hueBase = 0.62 + 0.12 * Double(lv.mid) + 0.03 * sin(Double(t) * 0.07)
        hueBase -= hueBase.rounded(.down)
        for i in 0..<K {
            let f = Double(i) / Double(K - 1)
            var hue = hueBase + 0.18 * f
            hue -= hue.rounded(.down)
            mats[i].emission.contents = NSColor(hue: CGFloat(hue),
                                                saturation: CGFloat(0.85 - 0.3 * f),
                                                brightness: CGFloat(min(1, 0.02 + 1.1 * pow(f, 1.8))),
                                                alpha: 1)
        }

        // Slow camera drift; leans in a little on the swell.
        let a = 0.25 * sin(t * 0.05)
        let R: Float = 14 - 1.2 * swell
        let H: Float = 12 - 0.6 * swell
        cameraNode.simdPosition = SIMD3<Float>(R * sin(a), H, R * cos(a))
        cameraNode.simdLook(at: SIMD3<Float>(0, 0, -1))
    }
}
