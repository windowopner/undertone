import Foundation
import AVFoundation
import CoreMedia
import ScreenCaptureKit

struct Levels {
    var level: Float = 0
    var bass: Float = 0
    var mid: Float = 0
    var high: Float = 0
    var beat: Float = 0

    func scaled(_ s: Double) -> Levels {
        let f = Float(s)
        func c(_ v: Float) -> Float { min(1, v * f) }
        return Levels(level: c(level), bass: c(bass), mid: c(mid), high: c(high), beat: beat)
    }
}

/// Captures system audio (whatever is playing — Spotify, Apple Music, YouTube…)
/// via ScreenCaptureKit and turns it into smoothed 0…1 levels.
final class AudioReactor: NSObject, SCStreamOutput, SCStreamDelegate {
    private var stream: SCStream?
    private let queue = DispatchQueue(label: "undertone.audio")
    private let lock = NSLock()
    private var current = Levels()

    // DSP state (audio queue only)
    private var lpB: Float = 0
    private var lpM: Float = 0
    private var peaks: [Float] = [0.05, 0.05, 0.05, 0.05]
    private var smooth = Levels()
    private var bassAvg: Float = 0
    private var lastBeat: TimeInterval = 0

    /// Read on the main thread for the menu.
    private(set) var status = "연결 중…"

    func snapshot() -> Levels {
        lock.lock(); defer { lock.unlock() }
        return current
    }

    func start() {
        Task { await self.startCapture() }
    }

    func restart() {
        if let s = stream {
            stream = nil
            s.stopCapture { _ in }
        }
        setStatus("연결 중…")
        start()
    }

    private func setStatus(_ s: String) {
        DispatchQueue.main.async { self.status = s }
    }

    private func startCapture() async {
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            guard let display = content.displays.first else {
                setStatus("디스플레이를 못 찾음")
                return
            }
            let filter = SCContentFilter(display: display, excludingWindows: [])
            let config = SCStreamConfiguration()
            config.capturesAudio = true
            config.excludesCurrentProcessAudio = true
            config.sampleRate = 48000
            config.channelCount = 2
            // We only want audio; keep the video side as cheap as possible.
            config.width = 2
            config.height = 2
            config.minimumFrameInterval = CMTime(value: 1, timescale: 1)

            let s = SCStream(filter: filter, configuration: config, delegate: self)
            try s.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue)
            try s.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
            try await s.startCapture()
            stream = s
            setStatus("듣는 중")
        } catch {
            setStatus("권한 필요 — 화면 및 시스템 오디오 녹음 허용")
        }
    }

    // MARK: SCStreamDelegate

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        self.stream = nil
        setStatus("끊김 — 다시 연결 중…")
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in self?.start() }
    }

    // MARK: SCStreamOutput

    func stream(_ stream: SCStream, didOutputSampleBuffer sb: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, sb.isValid else { return }
        process(sb)
    }

    private func process(_ sb: CMSampleBuffer) {
        guard let fmt = CMSampleBufferGetFormatDescription(sb),
              let asbdPtr = CMAudioFormatDescriptionGetStreamBasicDescription(fmt) else { return }
        let asbd = asbdPtr.pointee
        guard asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0, asbd.mBitsPerChannel == 32 else { return }
        let fs = Float(asbd.mSampleRate > 0 ? asbd.mSampleRate : 48000)

        var sizeNeeded = 0
        CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(
            sb, bufferListSizeNeededOut: &sizeNeeded, bufferListOut: nil, bufferListSize: 0,
            blockBufferAllocator: nil, blockBufferMemoryAllocator: nil, flags: 0, blockBufferOut: nil)
        guard sizeNeeded > 0 else { return }

        let raw = UnsafeMutableRawPointer.allocate(byteCount: sizeNeeded,
                                                   alignment: MemoryLayout<AudioBufferList>.alignment)
        defer { raw.deallocate() }
        let abl = raw.bindMemory(to: AudioBufferList.self, capacity: 1)
        var block: CMBlockBuffer?
        let st = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(
            sb, bufferListSizeNeededOut: nil, bufferListOut: abl, bufferListSize: sizeNeeded,
            blockBufferAllocator: nil, blockBufferMemoryAllocator: nil,
            flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, blockBufferOut: &block)
        guard st == noErr else { return }

        let buffers = UnsafeMutableAudioBufferListPointer(abl)
        let interleaved = asbd.mFormatFlags & kAudioFormatFlagIsNonInterleaved == 0
        let chPerBuf = interleaved ? max(Int(asbd.mChannelsPerFrame), 1) : 1
        guard let buf0 = buffers.first, let p0 = buf0.mData else { return }
        let frames = Int(buf0.mDataByteSize) / (MemoryLayout<Float>.size * chPerBuf)
        guard frames > 0 else { return }

        let channels: [UnsafeMutablePointer<Float>] = interleaved
            ? [p0.assumingMemoryBound(to: Float.self)]
            : buffers.compactMap { $0.mData?.assumingMemoryBound(to: Float.self) }

        // One-pole filters split the signal into bass (<150 Hz), mid (150–2k), high (>2k).
        let aB = 1 - exp(-2 * Float.pi * 150 / fs)
        let aM = 1 - exp(-2 * Float.pi * 2000 / fs)
        var sB: Float = 0, sM: Float = 0, sH: Float = 0, sAll: Float = 0

        for i in 0..<frames {
            var x: Float = 0
            if interleaved {
                let p = channels[0]
                for c in 0..<chPerBuf { x += p[i * chPerBuf + c] }
                x /= Float(chPerBuf)
            } else {
                for p in channels { x += p[i] }
                x /= Float(max(channels.count, 1))
            }
            lpB += aB * (x - lpB)
            lpM += aM * (x - lpM)
            let b = lpB, m = lpM - lpB, h = x - lpM
            sB += b * b; sM += m * m; sH += h * h; sAll += x * x
        }

        let n = Float(frames)
        update(level: sqrt(sAll / n), bass: sqrt(sB / n), mid: sqrt(sM / n), high: sqrt(sH / n))
    }

    private func update(level: Float, bass: Float, mid: Float, high: Float) {
        // Auto-gain: divide by a slowly decaying peak so quiet and loud tracks both move the visuals.
        func norm(_ v: Float, _ i: Int) -> Float {
            peaks[i] = max(v, peaks[i] * 0.999, 0.02)
            return min(1, v / peaks[i])
        }
        func ease(_ cur: Float, _ tgt: Float) -> Float {
            cur + (tgt - cur) * (tgt > cur ? 0.55 : 0.12)
        }
        smooth.level = ease(smooth.level, norm(level, 0))
        smooth.bass = ease(smooth.bass, norm(bass, 1))
        smooth.mid = ease(smooth.mid, norm(mid, 2))
        smooth.high = ease(smooth.high, norm(high, 3))

        // Simple beat detector: bass jumps well above its running average.
        let now = ProcessInfo.processInfo.systemUptime
        bassAvg += (bass - bassAvg) * 0.05
        if bass > bassAvg * 1.35 && bass > 0.01 && now - lastBeat > 0.22 {
            smooth.beat = 1
            lastBeat = now
        } else {
            smooth.beat *= 0.85
        }

        lock.lock()
        current = smooth
        lock.unlock()
    }
}
